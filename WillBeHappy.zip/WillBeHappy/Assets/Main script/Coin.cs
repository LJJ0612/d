using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{

   private AudioSource aud;

   public int coinAmount = 0;

   void Start()
   {
      aud = GetComponent<AudioSource>();
   }

   private void OnCollisionEnter2D(Collision2D other) {
      if(other.gameObject.tag == "Coin") {
         Destroy(other.gameObject);
         coinAmount++;
         aud.Play();
      }
   }

   public void resetCoinAmount() {
      coinAmount = 0;
   }
}
